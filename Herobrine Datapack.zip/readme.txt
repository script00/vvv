First, you need to put datapack in datapack folderOnce in, type /reload to reload the datapack.
But you need to activate herobrine himself by building the totem.
First, you need to build the totem. 
There can be only one!

/function main:clear to remove datapack's scores etc.
/reload to reset the datapack to normal

Warning: do NOT type /reload while being in nightmare -> breaks the datapack!